#!/usr/bin/env python3


from pololu_drv8835_rpi import motors

motors.motor1.setSpeed(0)
motors.motor2.setSpeed(0)
